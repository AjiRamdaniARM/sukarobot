<body>

    <!-- ======= Header ======= -->
    <header id="header" class="fixed-top">
      <div class="container d-flex align-items-center">
  
        <a href="<?php echo e(url('/')); ?>" class="logo me-auto"><img src="assets/img/Untitled-2.png"></a>
        <!-- Uncomment below if you prefer to use an image logo -->
  
        <nav id="navbar" class="navbar order-last order-lg-0">
          <ul>
            <li><a class="<?php echo e(Request::is('/') ? 'active' : ''); ?>" href="<?php echo e(url('/')); ?>">Home</a></li>
            <li><a class="<?php echo e(Request::is('home/about') ? 'active' : ''); ?>" href="<?php echo e(url('/home/about')); ?>">Tentang Kami</a></li>
            <li><a class="<?php echo e(Request::is('home/pelatihan') ? 'active' : ''); ?>" href="<?php echo e(url('/home/pelatihan')); ?>">Pelatihan</a></li>
            <li><a class="<?php echo e(Request::is('home/instruktur') ? 'active' : ''); ?>" href="<?php echo e(url('/home/instruktur')); ?>">Instruktur</a></li>
            <li><a class="<?php echo e(Request::is('home/galeri') ? 'active' : ''); ?>" href="<?php echo e(url('/home/galeri')); ?>">Galeri</a></li>
            <li><a class="<?php echo e(Request::is('home/contact') ? 'active' : ''); ?>" href="<?php echo e(url('/home/contact')); ?>">Hubungi Kami</a></li>
            <?php if(Route::has('login')): ?>
            <?php if(auth()->guard()->check()): ?>
            <li class="dropdown"><a href="/dashboard"><span><?php echo e(Auth::user()->name); ?></span> <i class="bi bi-chevron-down"></i></a>
              <ul>
                <li><a href="<?php echo e(url('/dashboard')); ?>">Dashboard<i class="bi bi-columns-gap"></i></a></li>
                <li><a href="/logout">Logout<i class="bi bi-box-arrow-right"></i></a></li>
              </ul>
            </li>
            <?php endif; ?>
            <?php endif; ?>
          </ul>
          <i class="bi bi-list mobile-nav-toggle"></i>
        </nav><!-- .navbar -->
        <?php if(!auth()->check()): ?>
          <a href="<?php echo e(route('login')); ?>" class="get-started-btn">Login</a>
          <?php endif; ?>
      </div>
    </header><!-- End Header -->
  
    <?php /**PATH C:\xampp\htdocs\SukaRobot\resources\views/user/partial/navbar.blade.php ENDPATH**/ ?>