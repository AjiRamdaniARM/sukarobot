<?php echo $__env->make('admin.partial.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.partial.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.partial.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<main id="main" class="main">

    <div class="pagetitle">
        <h1>Dashboard</h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="index.html">Home</a></li>
                <li class="breadcrumb-item active">Dashboard</li>
            </ol>
        </nav>
    </div><!-- End Page Title -->

    <section class="section dashboard">
        <div class="row">
            <?php if(Auth::user()->role == 'admin'): ?>
                <!-- Left side columns -->
                <div class="col-lg-12">
                    <div class="row">

                        <!-- Sales Card -->
                        <div class="col-xxl-4 col-md-3">
                            <div class="card info-card sales-card">

                                <div class="card-body">
                                    <h5 class="card-title">Peserta <span>| All</span></h5>

                                    <div class="d-flex align-items-center">
                                        <div
                                            class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                                            <i class="bi bi-people"></i>
                                        </div>
                                        <div class="ps-2">
                                            <h6><?php echo e($user); ?></h6>
                                            <span class="text-muted small">User</span>

                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div><!-- End Sales Card -->

                        <!-- Revenue Card -->
                        <div class="col-xxl-4 col-md-3">
                            <div class="card info-card revenue-card">

                                <div class="card-body">
                                    <h5 class="card-title">Pelatihan <span>| All</span></h5>

                                    <div class="d-flex align-items-center">
                                        <div
                                            class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                                            <i class="bi bi-layout-text-window-reverse"></i>
                                        </div>
                                        <div class="ps-2">
                                            <h6><?php echo e($pelatihan); ?></h6>
                                            <span class="text-muted small">Pelatihan</span>

                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div><!-- End Revenue Card -->
                        <!-- Revenue Card -->
                        <div class="col-xxl-4 col-md-3">
                            <div class="card info-card customers-card">

                                <div class="card-body">
                                    <h5 class="card-title">Instruktur <span>| All</span></h5>

                                    <div class="d-flex align-items-center">
                                        <div
                                            class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                                            <i class="bi bi-person"></i>
                                        </div>
                                        <div class="ps-2">
                                            <h6><?php echo e($instruktur); ?></h6>
                                            <span class="text-muted small">Instruktur</span>

                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div><!-- End Revenue Card -->
                        <!-- Revenue Card -->
                        <div class="col-xxl-4 col-md-3">
                            <div class="card info-card galeri-card">

                                <div class="card-body">
                                    <h5 class="card-title">Galeri <span>| All</span></h5>

                                    <div class="d-flex align-items-center">
                                        <div
                                            class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                                            <i class="bi bi-image"></i>
                                        </div>
                                        <div class="ps-2">
                                            <h6><?php echo e($galeri); ?></h6>
                                            <span class="text-muted small">Kegiatan</span>

                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div><!-- End Revenue Card -->

                    </div>
                </div><!-- End Left side columns -->
            <?php endif; ?>
            <?php if(Auth::user()->role == 'user'): ?>
                <div class="col-lg-12">
                    <div class="row">

                        <!-- Sales Card -->
                        <div class="col-xxl-4 col-md-6">
                            <div class="card info-card sales-card">

                                <div class="card-body">
                                    <h5 class="card-title">Pelatihan <span>| All</span></h5>

                                    <div class="d-flex align-items-center">
                                        <div
                                            class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                                            <i class="bi bi-display"></i>
                                        </div>
                                        <div class="ps-3">
                                            <h6><?php echo e($pelatihanUser); ?></h6>
                                            <span class="text-muted small pt-2 ps-1">Pelatihan yang kamu miliki</span>

                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div><!-- End Sales Card -->
                        <!-- Sales Card -->
                        <div class="col-xxl-4 col-md-6">
                            <div class="card info-card revenue-card">

                                <div class="card-body">
                                    <h5 class="card-title">Sertifikat <span>| All</span></h5>

                                    <div class="d-flex align-items-center">
                                        <div
                                            class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                                            <i class="bi bi-card-list"></i>
                                        </div>
                                        <div class="ps-3">
                                            <h6><?php echo e($sertifikatUser); ?></h6>
                                            <span class="text-muted small pt-2 ps-1">Sertifikat yang kamu miliki</span>

                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div><!-- End Sales Card -->

                    </div>
                </div><!-- End Left side columns -->
            <?php endif; ?>

        </div>
    </section>
    <?php if(Auth::user()->role == 'admin'): ?>

        <section class="section">
            <div class="row">
                <div class="col-lg-12">
                    <?php if(session()->has('delete')): ?>
                        <div class="alert alert-danger bg-danger text-light border-0 alert-dismissible fade show"
                            role="alert">
                            <?php echo e(session()->get('delete')); ?>

                            <button type="button" class="btn-close btn-close-white" data-bs-dismiss="alert"
                                aria-label="Close"></button>
                        </div>
                    <?php endif; ?>
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title">Data Pesan</h5>

                            <!-- Table with stripped rows -->
                            <div class="table-responsive">
                                <table class="table datatable">
                                    <thead>
                                        <tr>
                                            <th scope="col">#</th>
                                            <th scope="col">Nama</th>
                                            <th scope="col">Email</th>
                                            <th scope="col">Subjek</th>
                                            <th scope="col">Pesan</th>
                                            <th scope="col">Aksi</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $pesan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <th scope="row">1</th>
                                                <td><?php echo e($item->name); ?></td>
                                                <td><?php echo e($item->email); ?></td>
                                                <td><?php echo e($item->subject); ?></td>
                                                <td><?php echo e(Str::limit($item->pesan, 10)); ?></td>
                                                <td>
                                                    <a href="<?php echo e(url('contact/detail', $item->id)); ?>"
                                                        class="btn btn-primary" type="button">Detail</a>
                                                    <a href="<?php echo e(url('contact/delete', $item->id)); ?>"
                                                        class="btn btn-danger"
                                                        onclick="return confirm('Yakin ingin menghapus?')"
                                                        type="button">Hapus</a>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </section>
    <?php endif; ?>

</main><!-- End #main -->
<?php echo $__env->make('admin.partial.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\xampp\htdocs\SukaRobot\resources\views/admin/index.blade.php ENDPATH**/ ?>