<?php echo $__env->make('admin.partial.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.partial.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.partial.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<main id="main" class="main">

    <div class="pagetitle">
        <h1>Data Transaksi</h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="index.html">Home</a></li>
                <li class="breadcrumb-item active">Data Transaksi</li>
            </ol>
        </nav>
    </div><!-- End Page Title -->
    <section class="section">
        <div class="row">
            <div class="col-lg-12">
                <?php if(session()->has('success')): ?>
                    <div class="alert alert-success bg-success text-light border-0 alert-dismissible fade show"
                        role="alert">
                        <?php echo e(session()->get('success')); ?>

                        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="alert"
                            aria-label="Close"></button>
                    </div>
                <?php endif; ?>
                <?php if(session()->has('error')): ?>
                    <div class="alert alert-danger bg-danger text-light border-0 alert-dismissible fade show"
                        role="alert">
                        <?php echo e(session()->get('error')); ?>

                        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="alert"
                            aria-label="Close"></button>
                    </div>
                <?php endif; ?>
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Data Transaksi</h5>
                        <p>Jika status pembayaran anda tidak memiliki perubahan, anda dapat bisa konfirmasi langsung kepada admin dengan menekan ikon Whatsapp</p>
                        <!-- Table with stripped rows -->
                        <div class="table-responsive">
                            <table class="table datatable">
                                <thead>
                                    <tr>
                                        <th scope="col">#</th>
                                        <th scope="col">Kode Transaksi</th>
                                        <th scope="col">Nama</th>
                                        <th scope="col">Pelatihan</th>
                                        <th scope="col">Pembayaran</th>
                                        <th scope="col">Status</th>
                                        <th scope="col">Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $payment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <th scope="row"><?php echo e($loop->iteration); ?></th>
                                            <td><?php echo e($item->id_transaksi); ?></td>
                                            <td><?php echo e($item->userId->name); ?></td>
                                            <td><?php echo e($item->pelatihanId->judul); ?></td>
                                            <td><img src="transaksi/<?php echo e($item->foto); ?>" alt="transaksi"
                                                    style="max-width: auto%; max-height: 50px;" class="rounded-circle">
                                            </td>
                                            <td>
                                                <button type="button"
                                                    class="btn <?php if($item->status == 'Berhasil'): ?> btn-outline-success 
                                                    <?php elseif($item->status == 'Gagal'): ?> btn-outline-danger 
                                                    <?php else: ?> btn-outline-primary <?php endif; ?>"
                                                    disabled><?php echo e($item->status); ?></button>
                                            </td>
                                            <td>
                                                <?php if(Auth::user()->role === 'admin'): ?>
                                                    <?php if($item->status == 'Diproses'): ?>
                                                        <a href="<?php echo e(url('/dashboard/transaksi/approve', $item->id)); ?>"
                                                            style="button" class="btn btn-success" title="approve"><i
                                                                class="bi bi-check-circle"></i></a>
                                                        <a href="<?php echo e(url('/dashboard/transaksi/reject', $item->id)); ?>"
                                                            style="button" class="btn btn-danger" title="tolak"><i
                                                                class="bi bi-x-circle"></i></a>
                                                    <?php endif; ?>
                                                <?php endif; ?>
                                                <a href="#" style="button" class="btn btn-primary" title="detail"
                                                    data-bs-toggle="modal"
                                                    data-bs-target="#verticalycentered<?php echo e($item->id); ?>"><i
                                                        class="bi bi-info-circle"></i></a>
                                                        <?php if(Auth::user()->role === 'user'): ?>
                                                            
                                                <a href="https://wa.me/6285795899901?text=Hallo!!Saya *<?php echo e($item->userId->name); ?>* ingin telah membayar pelatihan *<?php echo e($item->pelatihanId->judul); ?>* dengan nomor transaksi *<?php echo e($item->id_transaksi); ?>*"
                                                    type="button" target="_blank" class="btn btn-success"><i
                                                        class="bi bi-whatsapp"></i></a>
                                                        <?php endif; ?>

                                            </td>
                                            <div class="modal fade" id="verticalycentered<?php echo e($item->id); ?>"
                                                tabindex="-1">
                                                <div class="modal-dialog modal-dialog-centered">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h5 class="modal-title">Detail Bukti Pembayaran</h5>
                                                            <button type="button" class="btn-close"
                                                                data-bs-dismiss="modal" aria-label="Close"></button>
                                                        </div>
                                                        <div class="modal-body">
                                                            <img src="transaksi/<?php echo e($item->foto); ?>" alt="transaksi"
                                                                class="img-fluid mx-auto d-block">
                                                        </div>
                                                        <div class="modal-footer">
                                                            <button type="button" class="btn btn-secondary"
                                                                data-bs-dismiss="modal">Close</button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                        <!-- End Table with stripped rows -->

                    </div>
                </div>

            </div>
        </div>
    </section>

</main><!-- End #main -->

<?php echo $__env->make('admin.partial.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\xampp\htdocs\SukaRobot\resources\views/admin/component/transaksi.blade.php ENDPATH**/ ?>