<?php echo $__env->make('user.partial.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('user.partial.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<main id="main" data-aos="fade-in">

    <!-- ======= Breadcrumbs ======= -->
    <div class="breadcrumbs" data-aos="fade-in">
      <div class="container">
        <h2>Instruktur</h2>
        <p>Dengan pengetahuan dan keahlian yang mendalam di bidangnya, instruktur Kami bertanggung jawab untuk memberikan bimbingan, pengajaran, dan pemahaman kepada Anda.</p>
      </div>
    </div><!-- End Breadcrumbs -->

    <!-- ======= Trainers Section ======= -->
    <section id="trainers" class="trainers">
        <div class="container" data-aos="fade-up">
            <div class="row" data-aos="zoom-in" data-aos-delay="100">
              <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-4 col-md-6 d-flex align-items-stretch">
              <div class="member">
                <img src="Instruktur/<?php echo e($item->foto); ?>" class="img-fluid" alt="">
                <div class="member-content">
                  <h4><?php echo e($item->nama); ?></h4>
                  <span><?php echo e($item->kategori->kategori); ?></span>
                  <p>
                      <?php echo e($item->deksripsi); ?>

                  </p>
                </div>
              </div>
            </div>
  
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
  
        </div>
      </section><!-- End Trainers Section -->
  
    </main><!-- End #main -->

  </main><!-- End #main -->
  <?php echo $__env->make('user.partial.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\SukaRobot\resources\views/user/component/instruktur.blade.php ENDPATH**/ ?>