<?php echo $__env->make('admin.partial.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php
    use Carbon\Carbon;
?>
<?php echo $__env->make('admin.partial.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.partial.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<main id="main" class="main">

    <div class="pagetitle">
        <h1>Pelatihan saya</h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="index.html">Home</a></li>
                <li class="breadcrumb-item active">Pelatihan saya</li>
            </ol>
        </nav>
    </div><!-- End Page Title -->
    <section class="section">
        <div class="row">
            <?php if(session()->has('success')): ?>
                <div class="alert alert-success bg-success text-light border-0 alert-dismissible fade show"
                    role="alert">
                    <?php echo e(session()->get('success')); ?>

                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="alert"
                        aria-label="Close"></button>
                </div>
            <?php endif; ?>
            <?php if(session()->has('error')): ?>
                <div class="alert alert-danger bg-danger text-light border-0 alert-dismissible fade show"
                    role="alert">
                    <?php echo e(session()->get('error')); ?>

                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="alert"
                        aria-label="Close"></button>
                </div>
            <?php endif; ?>
            <?php if($pelatihan->isEmpty()): ?>
                <p>Anda belum memiliki pelatihan.</p>
            <?php else: ?>
                <?php $__currentLoopData = $pelatihan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-4">
                        <div class="card">
                            <div class="card-body">
                                <p></p>
                                <!-- Slides only carousel -->
                                <div id="carouselExampleSlidesOnly" class="carousel slide" data-bs-ride="carousel">
                                    <div class="carousel-inner">
                                        <div class="carousel-item active">
                                            <img src="Pelatihan/<?php echo e($item->foto); ?>" class="d-block w-100"
                                                alt="...">
                                        </div>
                                    </div>
                                    <h5 class="card-title"><?php echo e($item->judul); ?></h5>
                                    <div class="d-flex justify-content-between">
                                        <a id="copyText" href="<?php echo e($item->link); ?>" class="text-success pt-1"
                                            target="_blank"><?php echo e(Str::limit($item->link, 25)); ?> </a>
                                        <a type="button" class="bi bi-files small" onclick="copyToClipboard()"></a>
                                        <script>
                                            function copyToClipboard() {
                                                /* Mendapatkan teks yang akan disalin */
                                                var copyText = document.getElementById("copyText");

                                                /* Membuat elemen textarea untuk menyimpan teks yang akan disalin */
                                                var textarea = document.createElement("textarea");
                                                textarea.value = copyText.textContent;
                                                document.body.appendChild(textarea);

                                                /* Memilih dan menyalin teks */
                                                textarea.select();
                                                document.execCommand("copy");

                                                /* Menghapus elemen textarea */
                                                document.body.removeChild(textarea);

                                                /* Memberikan umpan balik atau pemberitahuan */
                                                alert("Teks berhasil disalin: " + copyText.textContent);
                                            }
                                        </script>
                                    </div>
                                    <div class="d-flex justify-content-between">
                                        <a class="small pt-1"><?php echo e(\Carbon\Carbon::parse($item->time)->format('H:i')); ?> /
                                            <?php echo e(\Carbon\Carbon::parse($item->date)->isoFormat('DD-MM-YYYY')); ?></a>
                                        
                                            <a href="<?php echo e(url('/dashboard/user/pelatihan', $item->judul)); ?>"
                                                class="small pt-1" type="button">Upload Bukti</a>

                                    </div>
                                </div><!-- End Slides only carousel-->
                            </div>
                        </div>

                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </div>
    </section>

</main><!-- End #main -->

<?php echo $__env->make('admin.partial.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\xampp\htdocs\SukaRobot\resources\views/admin/component/user-pelatihan.blade.php ENDPATH**/ ?>