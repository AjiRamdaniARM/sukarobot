<?php echo $__env->make('user.partial.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<style type="text/css">
    .left {
        text-align: left;
    }

    .right {
        text-align: right;
    }

    .center {
        text-align: center;
    }

    .justify {
        text-align: justify;
    }
</style>
<?php
    use Carbon\Carbon;
?>
<?php echo $__env->make('user.partial.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<main id="main">
    <br>

    <?php $__env->startSection('content'); ?>
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-8">
                    <div class="card">
                        <div class="card-header"><?php echo e(__('Verify Your Email Address')); ?></div>

                        <div class="card-body">
                            <?php if(session('resent')): ?>
                                <div class="alert alert-success" role="alert">
                                    <?php echo e(__('A fresh verification link has been sent to your email address.')); ?>

                                </div>
                            <?php endif; ?>

                            <?php echo e(__('Before proceeding, please check your email for a verification link.')); ?>

                            <?php echo e(__('If you did not receive the email')); ?>,
                            <form class="d-inline" method="POST" action="<?php echo e(route('verification.resend')); ?>">
                                <?php echo csrf_field(); ?>
                                <button type="submit"
                                    class="btn btn-link p-0 m-0 align-baseline"><?php echo e(__('click here to request another')); ?></button>.
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php $__env->stopSection(); ?>
    <!-- ======= Hero Section ======= -->
    <section id="hero" class="d-flex justify-content-center align-items-center">
        <div class="container position-relative" data-aos="zoom-in" data-aos-delay="100">
            <h1>Learning Today,<br>Leading Tomorrow</h1>
            <h2>Selamat datang di Website resmi Sukarobot Academy.</h2>
            <a href="<?php echo e(route('register')); ?>" class="btn-get-started">Ikuti Pelatihan</a>
        </div>
    </section><!-- End Hero -->
    <!-- ======= About Section ======= -->
    <section id="about" class="about">
        <div class="container" data-aos="fade-up">

            <div class="row">
                <div class="col-lg-6 order-1 order-lg-2" data-aos="fade-left" data-aos-delay="100">
                    <img src="assets/img/about.jpg" class="img-fluid" alt="">
                </div>
                <div class="col-lg-6 pt-4 pt-lg-0 order-2 order-lg-1 content">
                    <h3>“Sesuatu yang mudah kenapa harus dibuat sulit”
                    </h3>
                    <p class="justify">
                        Pada saat ini begitu banyak mimpi untuk kemajuan pendidikan, mulai dari biaya
                        murah berkualitas, kesejahteraan pengajar, sarana dan prasarana yang baik dan
                        memadai
                    </p>
                    <p class="justify">
                        Itu semua sebagian kecil dari mimpi kita bangsa Indonesia untuk pendidikan.
                        Lantas apa yang harus kita lakukan ?
                    </p>
                    <p class="justify">
                        Rasanya banyak hal yang tidak akan berarti jika kemajuan bangsa ini tidak dibarengi
                        dengan kemajuan SDM. Yang perlu anda ketahui untuk kami tentunya saya dan Nayaguna
                        Tech semua itu bukan lagi mimpi tapi PR yang akan kami kejar dan kami buktikan.
                    </p>
                    <p class="fst-italic"><b>
                            “Kita Yakin Kita Bisa !”</b>
                    </p>

                </div>
            </div>

        </div>
    </section><!-- End About Section -->

    <!-- ======= Counts Section ======= -->
    <section id="counts" class="counts section-bg">
        <div class="container">

            <div class="row counters">

                <div class="col-lg-3 col-6 text-center">
                    <span data-purecounter-start="0" data-purecounter-end="<?php echo e($user); ?>"
                        data-purecounter-duration="1" class="purecounter"></span>
                    <p>Students</p>
                </div>

                <div class="col-lg-3 col-6 text-center">
                    <span data-purecounter-start="0" data-purecounter-end="<?php echo e($countPel); ?>"
                        data-purecounter-duration="1" class="purecounter"></span>
                    <p>Pelatihan</p>
                </div>

                <div class="col-lg-3 col-6 text-center">
                    <span data-purecounter-start="0" data-purecounter-end="<?php echo e($countGal); ?>"
                        data-purecounter-duration="1" class="purecounter"></span>
                    <p>Galeri</p>
                </div>

                <div class="col-lg-3 col-6 text-center">
                    <span data-purecounter-start="0" data-purecounter-end="<?php echo e($countIns); ?>"
                        data-purecounter-duration="1" class="purecounter"></span>
                    <p>Instruktur</p>
                </div>

            </div>

        </div>
    </section><!-- End Counts Section -->
    <section id="why-us" class="why-us">
        <div class="container" data-aos="fade-up">
  
          <div class="row">
            <div class="col-lg-4 d-flex align-items-stretch">
              <div class="content">
                <h3>Mengapa Memilih Sukarobot Academy?</h3>
                <p>
                    Sukarobot Academy secara mampu holistik meningkatkan kreativitas, daya imajinasi, pola pikir inovatif, kemampuan programming dasar, kerja tim, dan keterampilan presentasi siswa.
                </p>
              </div>
            </div>
            <div class="col-lg-8 d-flex align-items-stretch" data-aos="zoom-in" data-aos-delay="100">
              <div class="icon-boxes d-flex flex-column justify-content-center">
                <div class="row">
                  <div class="col-xl-4 d-flex align-items-stretch">
                    <div class="icon-box mt-4 mt-xl-0">
                      <i class="bx bx-receipt"></i>
                      <h4>Ekstrakulikuler</h4>
                      <p>Mengajarkan siswa pembuatan robot dari dasar hingga tingkat lanjut, sesuai kurikulum dengan modul yang mudah dipahami.</p>
                    </div>
                  </div>
                  <div class="col-xl-4 d-flex align-items-stretch">
                    <div class="icon-box mt-4 mt-xl-0">
                      <i class="bx bx-cube-alt"></i>
                      <h4>Holiday Program</h4>
                      <p>Liburan bermanfaat, cintai teknologi lewat materi fun, proyek thematic, dan tingkatkan kerjasama serta tanggung jawab.</p>
                    </div>
                  </div>
                  <div class="col-xl-4 d-flex align-items-stretch">
                    <div class="icon-box mt-4 mt-xl-0">
                      <i class="bx bx-images"></i>
                      <h4>Workshop</h4>
                      <p>Mengajarkan robotic dalam format setengah hari atau sehari penuh, disesuaikan dengan tema dan tingkat akademik peserta.</p>
                    </div>
                  </div>
                </div>
              </div><!-- End .content-->
            </div>
          </div>
  
        </div>
      </section><!-- End Why Us Section -->

    <!-- ======= Popular Courses Section ======= -->
    <section id="popular-courses" class="courses">
        <div class="container" data-aos="fade-up">

            <div class="section-title">
                <h2>Pelatihan</h2>
                <p>Rekomendasi Pelatihan</p>
            </div>

            <div class="row" data-aos="zoom-in" data-aos-delay="100">

                <?php $__currentLoopData = $pelatihan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-4 col-md-6 d-flex align-items-stretch">
                        <div class="course-item">
                            <img src="Pelatihan/<?php echo e($item->foto); ?>" class="img-fluid" alt="...">
                            <div class="course-content">
                                <div class="d-flex justify-content-between align-items-center mb-3">
                                    <h4><?php echo e($item->kategoriId->kategori); ?></h4>
                                    <p class="price"><?php echo e('Rp ' . number_format($item->harga, 0, ',', '.')); ?></p>
                                </div>

                                <h3><a
                                        href="<?php echo e(url('/home/pelatihan-detail', $item->judul)); ?>"><?php echo e($item->judul); ?></a>
                                </h3>
                                <p><?php echo e(Str::limit($item->deskripsi, 100)); ?></p>
                                <div class="trainer d-flex justify-content-between align-items-center">
                                    <div class="trainer-profile d-flex align-items-center">
                                        <img src="Instruktur/<?php echo e($item->instrukturId->foto); ?>" class="img-fluid"
                                            alt="">
                                        <span><?php echo e($item->instrukturId->nama); ?></span>
                                    </div>
                                    <div class="trainer-rank d-flex align-items-center">
                                        <a id="whatsapp" class="ri ri-whatsapp-line small" target="_blank"
                                        onclick="copyShareWhatsapp('<?php echo e(url('/home/pelatihan-detail', $item->judul)); ?>', '<?php echo e($item->judul); ?>')"></a> &nbsp; 
                                        <script>
                                            function copyShareWhatsapp(url, judul) {
                                                // Buat link yang akan dibagikan
                                                var shareLink = url;
                                        
                                                // Dapatkan elemen dengan ID "whatsapp"
                                                var whatsappElement = document.getElementById('whatsapp');
                                        
                                                // Ganti link href dengan link WhatsApp yang sesuai
                                                whatsappElement.href = 'https://api.whatsapp.com/send?text=' + encodeURIComponent(shareLink);
                                        
                                                // Salin link ke clipboard (opsional)
                                                navigator.clipboard.writeText(shareLink).then(function() {
                                                    // Tampilkan pesan sukses atau lakukan tindakan lain
                                                    alert('Link telah disalin ke clipboard dan link WhatsApp telah diperbarui: ' + shareLink);
                                                }).catch(function(err) {
                                                    // Tampilkan pesan error atau lakukan tindakan lain
                                                    console.error('Gagal menyalin link: ', err);
                                                });
                                            }
                                        </script>
                                        <a class="bx bx-copy small"
                                        onclick="copyShareLink('<?php echo e(url('/home/pelatihan-detail', $item->judul)); ?>', '<?php echo e($item->judul); ?>')"></a>
                                    </div>
                                    <div class="modal fade" id="floatingNotificationModal" tabindex="-1" aria-labelledby="floatingNotificationModalLabel" aria-hidden="true">
                                        <div class="modal-dialog">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title" id="floatingNotificationModalLabel">Notifikasi</h5>
                                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                </div>
                                                <div class="modal-body">
                                                    <p>Tautan Pelatihan berhasil disalin!</p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <script>
                                        function copyShareLink(link, title) {
                                            var shareLinkInput = document.createElement('textarea');
                                            shareLinkInput.value = link;
                                            document.body.appendChild(shareLinkInput);
                                            shareLinkInput.select();
                                            document.execCommand('copy');
                                            document.body.removeChild(shareLinkInput);
                                    
                                            // Tampilkan modal notifikasi mengambang
                                            showFloatingNotificationModal();
                                        }
                                    
                                        function showFloatingNotificationModal() {
                                            var floatingNotificationModal = new bootstrap.Modal(document.getElementById('floatingNotificationModal'), {});
                                            floatingNotificationModal.show();
                                            
                                            // Sembunyikan modal setelah beberapa detik (opsional)
                                            setTimeout(function() {
                                                floatingNotificationModal.hide();
                                            }, 1000); // Atur waktu penutupan modal (misalnya, 3000 milidetik = 3 detik)
                                        }
                                    </script>
                                </div>
                            </div>
                        </div>
                    </div> <!-- End Course Item-->
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>

        </div>
    </section><!-- End Popular Courses Section -->

    <!-- ======= Trainers Section ======= -->
    <section id="events" class="events">
        <div class="container" data-aos="fade-up">
            <div class="section-title">
                <h2>Galeri</h2>
                <p>Galeri Kegiatan</p>
            </div>
            <div class="row" data-aos="zoom-in" data-aos-delay="100">
                <?php $__currentLoopData = $galeri; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-4 d-flex align-items-stretch">
                        <div class="card">
                            <div class="card-img">
                                <img src="Galeri/<?php echo e($item->foto); ?>" alt="...">
                            </div>
                            <div class="card-body">
                                <h5 class="card-title"><a
                                        href="<?php echo e(url('/home/galeri-detail', $item->id)); ?>"><?php echo e($item->judul); ?></a>
                                </h5>
                                <p class="fst-italic text-center">
                                    <?php echo e(Carbon::parse($item->created_at)->setTimezone('Asia/Jakarta')->format('l, d M Y')); ?>

                                </p>
                                <p class="card-text"><?php echo e(Str::limit($item->deskripsi, 50)); ?></p>
                            </div>

                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

        </div>
    </section><!-- End Trainers Section -->

    <!-- ======= Trainers Section ======= -->
    <section id="trainers" class="trainers">
        <div class="container" data-aos="fade-up">
            <div class="section-title">
                <h2>Instruktur</h2>
                <p>Instruktur Ahli</p>
            </div>
            <div class="row" data-aos="zoom-in" data-aos-delay="100">
                <?php $__currentLoopData = $instruktur; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-4 col-md-6 d-flex align-items-stretch">
                        <div class="member">
                            <img src="Instruktur/<?php echo e($item->foto); ?>" class="img-fluid" alt="">
                            <div class="member-content">
                                <h4><?php echo e($item->nama); ?></h4>
                                <span><?php echo e($item->kategori->kategori); ?></span>
                            </div>

                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

        </div>
    </section><!-- End Trainers Section -->

</main><!-- End #main -->
<?php echo $__env->make('user.partial.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\xampp\htdocs\SukaRobot\resources\views/user/index.blade.php ENDPATH**/ ?>