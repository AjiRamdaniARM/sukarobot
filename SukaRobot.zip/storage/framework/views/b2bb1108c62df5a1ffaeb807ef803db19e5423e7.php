<?php echo $__env->make('admin.partial.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('admin.partial.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.partial.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



<main id="main" class="main">

    <div class="pagetitle">
        <h1>Sertifikat</h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="index.html">Home</a></li>
                <li class="breadcrumb-item active">Sertifikat</li>
            </ol>
        </nav>
    </div><!-- End Page Title -->
    <section class="section">
        <div class="row">
            <div class="col-lg-12">
                <?php if(session()->has('success')): ?>
                    <div class="alert alert-success bg-success text-light border-0 alert-dismissible fade show"
                        role="alert">
                        <?php echo e(session()->get('success')); ?>

                        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="alert"
                            aria-label="Close"></button>
                    </div>
                <?php endif; ?>
                <?php if(session()->has('edit')): ?>
                    <div class="alert alert-warning bg-warning text-light border-0 alert-dismissible fade show"
                        role="alert">
                        <?php echo e(session()->get('edit')); ?>

                        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="alert"
                            aria-label="Close"></button>
                    </div>
                <?php endif; ?>
                <?php if(session()->has('delete')): ?>
                    <div class="alert alert-danger bg-danger text-light border-0 alert-dismissible fade show"
                        role="alert">
                        <?php echo e(session()->get('delete')); ?>

                        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="alert"
                            aria-label="Close"></button>
                    </div>
                <?php endif; ?>
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Tambah Sertifikat</h5>

                        <!-- Horizontal Form -->
                        <form action="<?php echo e(url('/sertifikat/post')); ?>" method="POST" class="row g-3"
                            enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="col-md-6">
                                <div class="form-floating mb-7">
                                    <select class="form-select" name="id_user" id="floatingSelect" aria-label="State"
                                        required>
                                        <?php $__currentLoopData = $bukti; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($item->id_user); ?>"><?php echo e($item->userId->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <label for="floatingSelect">Nama Peserta</label>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-floating mb-7">
                                    <select class="form-select" name="id_pelatihan" id="floatingSelect"
                                        aria-label="State" required>
                                        <?php $__currentLoopData = $bukti; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($item->id_pelatihan); ?>"><?php echo e($item->pelatihanId->judul); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <label for="floatingSelect">Pelatihan</label>
                                </div>
                            </div>
                            <div class="col-mb-6">
                                <div class="form-floating">
                                    <input type="file" class="form-control" name="file" id="gambarInput"
                                        accept=".pdf" required>
                                    <br>
                                </div>
                            </div>

                            <div class="text-center">
                                <button type="submit" id="modal1" class="btn btn-primary">Submit</button>
                                <button type="reset" class="btn btn-secondary">Reset</button>
                            </div>
                        </form><!-- End Horizontal Form -->
                        <!-- Modal -->

                    </div>
                </div>

            </div>

        </div>
        <div class="row">
            <div class="col-lg-12">

                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Data Sertifikat</h5>
                        
                        <!-- Table with stripped rows -->
                        <table class="table datatable">
                            <thead>
                                <tr>
                                    <th scope="col">#</th>
                                    <th scope="col">Nama</th>
                                    <th scope="col">Pelatihan</th>
                                    <th scope="col">Sertifikat</th>
                                    <th scope="col">Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $sertifikat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <th scope="row"><?php echo e($loop->iteration); ?></th>
                                        <td><?php echo e($item->userId->name); ?></td>
                                        <td><?php echo e($item->pelatihanId->kategori); ?></td>
                                        <td> <?php echo e($item->file); ?></td>
                                        <td>
                                            <a href="<?php echo e(url('/sertifikat/delete', $item->id)); ?>" style="button"
                                                onclick="return confirm('Yakin ingin menghapus?')"
                                                class="btn btn-danger">Hapus</a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <!-- End Table with stripped rows -->

                    </div>
                </div>

            </div>
        </div>
    </section>

</main><!-- End #main -->

<?php echo $__env->make('admin.partial.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\xampp\htdocs\SukaRobot\resources\views/admin/component/sertifikat.blade.php ENDPATH**/ ?>