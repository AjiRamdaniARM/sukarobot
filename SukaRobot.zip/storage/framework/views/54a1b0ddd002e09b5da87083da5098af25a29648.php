<?php echo $__env->make('user.partial.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<style type="text/css">
  .left    { text-align: left;}
  .right   { text-align: right;}
  .center  { text-align: center;}
  .justify { text-align: justify;}
</style>
<?php echo $__env->make('user.partial.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



  <main id="main" data-aos="fade-in">
    <!-- ======= Breadcrumbs ======= -->
    <div class="breadcrumbs" data-aos="fade-in">
      <div class="container">
        <h2>Tentang Kami</h2>
        <p>Kenalan lebih dekat sama sejarah Sukarobot Academy dan orang-orang dibaliknya</p>
      </div>
    </div><!-- End Breadcrumbs -->

    <!-- ======= About Section ======= -->
    <section id="about" class="about">
      <div class="container" data-aos="fade-up">

        <div class="row">
          <div class="col-lg-12 pt-4 pt-lg-0 order-2 order-lg-1 content">
            <div class="section-title">
              <h2>Sejarah</h2>
              <p>Sejarah Sukarobot Academy</p>
            </div>
              <p class="justify">Sukarobot Academy merupakan Lembaga pendidikan non formal fokus memberikan edukasi bidang robotik dan koding yang dapat membangkitkan daya kreativitas, imajinasi dan inovasi anak di bawah naungan PT Sukarobot Academy Indonesia.</p>
              <p class="justify">PT Sukarobot Academy Indonesia memiliki bidang usaha yaitu : lembaga pendidikan dan pelatihan, Tempat Uji Kompetensi bidang TIK, dan project centre bidang TIK,Robotika, IoT, Aplikasi berbasis web. Sukarobot Academy telah dirintis di Sukabumi sejak bulan Agustus tahun 2021 , mengawali kerjasama dengan 2 (dua) sekolah, dengan total siswa 50 orang. Pada tahun 2022 sukarobot telah bekerjasa denga 15 Sekolah dengan total siswa 275 siswa, Univesitas Nusa Putra, Pemerintah kota dan kabupaten Sukabumi serta Dinas Perpustakaan dan Arsip Kota Kota Sukabumi. </p>
              <p class="justify">Pada tahun 2023 Sukarobot Academy sudah memiliki 3 cabang, yang berlokasi di Sukabumi, Surabaya dan bogor, dan pada saat ini sudah memiliki 36 partner kerjasama sekolah dan lembaga lainnya.  Sukarobot Academy terus berupaya untuk meningkatkan kualitas pembelajaran yang dapat menghasilkan peserta didik yang siap untuk berinovasi dan berprestasi.</p>
          </div>
        </div>

      </div>
    </section><!-- End About Section -->


    <!-- ======= About Section ======= -->
    <section id="about" class="about">
      <div class="container" data-aos="fade-up">

        <div class="row">
          
          <div class="col-lg-12 pt-4 pt-lg-0 order-2 order-lg-1 content">
            <div class="section-title">
              <h2>Visi & Misi</h2>
              <p>Visi & Misi Sukarobot Academy</p>
            </div>
            <h3>Visi</h3>
            <ul>
              <li><i class="bi bi-check-circle"></i> Mewujudkan dan Melahirkan sumberdaya manusia yang berinovatif dan kreatif dalam teknologi, serta siap menghadapi tantangan di era global.</li>
            </ul>
            <h3>Misi</h3>
            <ul>
              <li><i class="bi bi-check-circle"></i> Menyiapkan lulusan yang berkualitas sesuai perkembangan ilmu pengetahuan dan teknologi.</li>
              <li><i class="bi bi-check-circle"></i> Meningkatkan riset inovasi dalam teknologi.</li>
              <li><i class="bi bi-check-circle"></i> Menerapkan model pembelajaran digitalisasi.</li>
            </ul>
          </div>
        </div>

      </div>
    </section><!-- End About Section -->
    
  </main><!-- End #main -->

  <?php echo $__env->make('user.partial.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\SukaRobot\resources\views/user/component/about.blade.php ENDPATH**/ ?>