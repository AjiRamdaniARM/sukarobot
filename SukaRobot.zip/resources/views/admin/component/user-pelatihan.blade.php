@include('admin.partial.header')
@php
    use Carbon\Carbon;
@endphp
@include('admin.partial.navbar')
@include('admin.partial.sidebar')


<main id="main" class="main">

    <div class="pagetitle">
        <h1>Pelatihan saya</h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="index.html">Home</a></li>
                <li class="breadcrumb-item active">Pelatihan saya</li>
            </ol>
        </nav>
    </div><!-- End Page Title -->
    <section class="section">
        <div class="row">
            @if (session()->has('success'))
                <div class="alert alert-success bg-success text-light border-0 alert-dismissible fade show"
                    role="alert">
                    {{ session()->get('success') }}
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="alert"
                        aria-label="Close"></button>
                </div>
            @endif
            @if (session()->has('error'))
                <div class="alert alert-danger bg-danger text-light border-0 alert-dismissible fade show"
                    role="alert">
                    {{ session()->get('error') }}
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="alert"
                        aria-label="Close"></button>
                </div>
            @endif
            @if ($pelatihan->isEmpty())
                <p>Anda belum memiliki pelatihan.</p>
            @else
                @foreach ($pelatihan as $item)
                    <div class="col-lg-4">
                        <div class="card">
                            <div class="card-body">
                                <p></p>
                                <!-- Slides only carousel -->
                                <div id="carouselExampleSlidesOnly" class="carousel slide" data-bs-ride="carousel">
                                    <div class="carousel-inner">
                                        <div class="carousel-item active">
                                            <img src="Pelatihan/{{ $item->foto }}" class="d-block w-100"
                                                alt="...">
                                        </div>
                                    </div>
                                    <h5 class="card-title">{{ $item->judul }}</h5>
                                    <div class="d-flex justify-content-between">
                                        <a id="copyText" href="{{ $item->link }}" class="text-success pt-1"
                                            target="_blank">{{ Str::limit($item->link, 25) }} </a>
                                        <a type="button" class="bi bi-files small" onclick="copyToClipboard()"></a>
                                        <script>
                                            function copyToClipboard() {
                                                /* Mendapatkan teks yang akan disalin */
                                                var copyText = document.getElementById("copyText");

                                                /* Membuat elemen textarea untuk menyimpan teks yang akan disalin */
                                                var textarea = document.createElement("textarea");
                                                textarea.value = copyText.textContent;
                                                document.body.appendChild(textarea);

                                                /* Memilih dan menyalin teks */
                                                textarea.select();
                                                document.execCommand("copy");

                                                /* Menghapus elemen textarea */
                                                document.body.removeChild(textarea);

                                                /* Memberikan umpan balik atau pemberitahuan */
                                                alert("Teks berhasil disalin: " + copyText.textContent);
                                            }
                                        </script>
                                    </div>
                                    <div class="d-flex justify-content-between">
                                        <a class="small pt-1">{{ \Carbon\Carbon::parse($item->time)->format('H:i') }} /
                                            {{ \Carbon\Carbon::parse($item->date)->isoFormat('DD-MM-YYYY') }}</a>
                                        
                                            <a href="{{ url('/dashboard/user/pelatihan', $item->judul) }}"
                                                class="small pt-1" type="button">Upload Bukti</a>

                                    </div>
                                </div><!-- End Slides only carousel-->
                            </div>
                        </div>

                    </div>
                @endforeach
            @endif
        </div>
    </section>

</main><!-- End #main -->

@include('admin.partial.footer')
