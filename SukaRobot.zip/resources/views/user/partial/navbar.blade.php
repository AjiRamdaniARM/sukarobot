<body>

    <!-- ======= Header ======= -->
    <header id="header" class="fixed-top">
      <div class="container d-flex align-items-center">
  
        <a href="{{url('/')}}" class="logo me-auto"><img src="assets/img/Untitled-2.png"></a>
        <!-- Uncomment below if you prefer to use an image logo -->
  
        <nav id="navbar" class="navbar order-last order-lg-0">
          <ul>
            <li><a class="{{ Request::is('/') ? 'active' : '' }}" href="{{url('/')}}">Home</a></li>
            <li><a class="{{ Request::is('home/about') ? 'active' : '' }}" href="{{url('/home/about')}}">Tentang Kami</a></li>
            <li><a class="{{ Request::is('home/pelatihan') ? 'active' : '' }}" href="{{url('/home/pelatihan')}}">Pelatihan</a></li>
            <li><a class="{{ Request::is('home/instruktur') ? 'active' : '' }}" href="{{url('/home/instruktur')}}">Instruktur</a></li>
            <li><a class="{{ Request::is('home/galeri') ? 'active' : '' }}" href="{{url('/home/galeri')}}">Galeri</a></li>
            <li><a class="{{ Request::is('home/contact') ? 'active' : '' }}" href="{{url('/home/contact')}}">Hubungi Kami</a></li>
            @if (Route::has('login'))
            @auth
            <li class="dropdown"><a href="/dashboard"><span>{{Auth::user()->name}}</span> <i class="bi bi-chevron-down"></i></a>
              <ul>
                <li><a href="{{url('/dashboard')}}">Dashboard<i class="bi bi-columns-gap"></i></a></li>
                <li><a href="/logout">Logout<i class="bi bi-box-arrow-right"></i></a></li>
              </ul>
            </li>
            @endauth
            @endif
          </ul>
          <i class="bi bi-list mobile-nav-toggle"></i>
        </nav><!-- .navbar -->
        @if(!auth()->check())
          <a href="{{ route('login') }}" class="get-started-btn">Login</a>
          @endif
      </div>
    </header><!-- End Header -->
  
    