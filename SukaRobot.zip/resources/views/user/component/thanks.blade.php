
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">Terima Kasih!</div>
                    <div class="card-body">
                        <p>Transaksi Anda telah berhasil. Terima kasih atas pembayarannya!</p>
                        {{-- Tambahkan konten tambahan atau tautan kembali ke halaman lain jika diperlukan --}}
                    </div>
                </div>
            </div>
        </div>
    </div>
