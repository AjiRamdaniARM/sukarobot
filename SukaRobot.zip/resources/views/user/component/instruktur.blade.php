@include('user.partial.header')
@include('user.partial.navbar')


<main id="main" data-aos="fade-in">

    <!-- ======= Breadcrumbs ======= -->
    <div class="breadcrumbs" data-aos="fade-in">
      <div class="container">
        <h2>Instruktur</h2>
        <p>Dengan pengetahuan dan keahlian yang mendalam di bidangnya, instruktur Kami bertanggung jawab untuk memberikan bimbingan, pengajaran, dan pemahaman kepada Anda.</p>
      </div>
    </div><!-- End Breadcrumbs -->

    <!-- ======= Trainers Section ======= -->
    <section id="trainers" class="trainers">
        <div class="container" data-aos="fade-up">
            <div class="row" data-aos="zoom-in" data-aos-delay="100">
              @foreach ($data as $item)
            <div class="col-lg-4 col-md-6 d-flex align-items-stretch">
              <div class="member">
                <img src="Instruktur/{{$item->foto}}" class="img-fluid" alt="">
                <div class="member-content">
                  <h4>{{$item->nama}}</h4>
                  <span>{{$item->kategori->kategori}}</span>
                  <p>
                      {{$item->deksripsi}}
                  </p>
                </div>
              </div>
            </div>
  
            @endforeach
          </div>
  
        </div>
      </section><!-- End Trainers Section -->
  
    </main><!-- End #main -->

  </main><!-- End #main -->
  @include('user.partial.footer')