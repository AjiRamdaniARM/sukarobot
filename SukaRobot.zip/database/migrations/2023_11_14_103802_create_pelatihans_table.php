<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreatePelatihansTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('pelatihans', function (Blueprint $table) {
            $table->id();
            $table->string('judul');
            $table->string('harga');
            $table->string('foto');
            $table->string('date');
            $table->string('time');
            $table->string('link');
            $table->enum('status', ['Menunggu','Berlangsung','Berakhir'])->default('Menunggu');
            $table->text('deskripsi');
            $table->unsignedBigInteger('id_kategori');
            $table->unsignedBigInteger('id_instruktur');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('pelatihans');
    }
}
