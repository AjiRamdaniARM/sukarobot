<?php

namespace App\Http\Controllers;

use App\Models\Bukti;
use App\Models\Pelatihan;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Illuminate\Support\Facades\Auth;

class BuktiController extends Controller
{
    public function index($judul){
        $pelatihan = Pelatihan::where('judul', $judul)->firstOrFail();
        return view('admin.component.bukti', compact('pelatihan'));
    }
    public function indexAdm(){
        $bukti = Bukti::all();
        return view('admin.component.bukti-view', compact('bukti'));
    }

    public function post(Request $request, $judul){
        $userId = Auth::id();
        $pelatihan = Pelatihan::where('judul', $judul)->value('id');
        $existingBukti = Bukti::where('id_user', $userId)
                          ->where('id_pelatihan', $pelatihan)
                          ->first();

        if ($existingBukti) {
            // Jika sudah ada bukti, beri respons atau redirect sesuai kebutuhan
            return redirect('/dashboard/user/pelatihan')->with('error','Anda sudah mengupload bukti untuk pelatihan ini.');
        }
        $bukti = new Bukti();
        $bukti -> q1 = $request -> q1;
        $bukti -> q2 = $request -> q2;
        $bukti -> id_user = $userId;
        $bukti -> id_pelatihan = $pelatihan;
        $image = $request -> foto;
        $imagename=time().'.'.$image->getClientOriginalExtension();
        $request -> foto -> move('Bukti', $imagename);
        $bukti -> foto=$imagename;
        $bukti -> save();
        return redirect('/dashboard/user/pelatihan')->with('success','Bukti Berhasil di Upload!');
    }
}
