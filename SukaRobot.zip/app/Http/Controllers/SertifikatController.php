<?php

namespace App\Http\Controllers;

use Carbon\Carbon;
use App\Models\User;
use App\Models\Kategori;
use App\Models\Sertifikat;
use Illuminate\Http\Request;
use Barryvdh\DomPDF\Facade\Pdf;
use App\Http\Controllers\Controller;
use App\Models\Bukti;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;

class SertifikatController extends Controller
{
    function index(){
        $user = User::where('role', 'user')->get();
        $sertifikat = Sertifikat::all();
        $bukti = Bukti::all();
        $kompetensi = Kategori::all();
        return view('admin.component.sertifikat', compact('kompetensi','sertifikat', 'user', 'bukti'));
    }

    function post(Request $request){

        $data = new Sertifikat();

    
        $id_user = $request->id_user;
        $id_pelatihan = $request->id_pelatihan;

        $data -> id_user = $id_user;
        $data->id_pelatihan = $id_pelatihan;
        $file = $request -> file('file');
        $filename=time().'.'.$file->getClientOriginalExtension();
        $request -> file -> move('Sertifikat', $filename);
        $data -> file=$filename;
        $data -> save();
        return redirect('/dashboard/sertifikat')->with('success','Sertifikat Berhasil di Upload!');
    }


    function delete($id){
        $data = Sertifikat::find($id);
        $data->delete();
        return redirect('/dashboard/sertifikat')->with('delete','Sertifikat Berhasil di Hapus!');
    }

    public function userIndex(){
        $userId = Auth::id();
        $sertifikat = Sertifikat::where('id_user', $userId)->get();
        return view('admin.component.user-sertifikat', compact('sertifikat'));
    }
    
}
