<?php

namespace App\Http\Controllers;

use App\Models\Pelatihan;
use App\Models\Transaksi;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;

class TransaksiController extends Controller
{
    public function index($judul){
        $pelatihan = Pelatihan::where('judul', $judul)->firstOrFail();
        return view('user.component.payment', compact('pelatihan'));
    }
    public function thanks(){
        return view('user.component.thanks');
    }
    public function payment(Request $request, $judul){
        $idUser = Auth::id();
        $idPelatihan = Pelatihan::where('judul', $judul)->value('id');
        $initials = implode('', array_map('strtoupper', array_map('substr', explode(' ', $judul), array_fill_keys(range(0, count(explode(' ', $judul))), -1))));

        // Membuat ID transaksi acak berdasarkan inisial judul pelatihan, tanggal, bulan, tahun, dan ID user
        $idTransaksi ="SRA" . $initials . date('Ymd') . $idUser . mt_rand(1000, 9999);
        $payment = new Transaksi();
        $payment->id_transaksi = $idTransaksi;
        $payment->id_user = $idUser;
        $payment->id_pelatihan = $idPelatihan;
        $image = $request -> foto;
        $imagename=time().'.'.$image->getClientOriginalExtension();
        $request -> foto -> move('transaksi', $imagename);
        $payment -> foto=$imagename;
        $payment -> save();
        return redirect()->back()->with('success', 'Transaksi Anda telah proses. Terima kasih atas pembayarannya!');
    }

    public function view(){
        $userId = Auth::id();
        if (Auth::user()->role == 'admin') {
        $payment = Transaksi::all();
        } else {
        $payment = Transaksi::where('id_user', $userId)->get();
        }
        return view('admin.component.transaksi', compact('payment'));
    }
    public function approve($id){
        $payment = Transaksi::find($id);
        $payment->status = 'Berhasil';
        $payment->save();
        return redirect('/dashboard/transaksi')->with('success', 'Transaksi berhasil disetujui.');
    }
    public function reject($id){
        $payment = Transaksi::find($id);
        $payment->status = 'Gagal';
        $payment->save();
        return redirect('/dashboard/transaksi')->with('error', 'Transaksi berhasil ditolak.');
    }

    
}
